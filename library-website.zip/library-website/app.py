from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "library_secret_key_2026"

# ─────────────────────────────────────────────
#  DATABASE SETUP
# ─────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect("library.db")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS books (
        book_id   INTEGER PRIMARY KEY AUTOINCREMENT,
        title     TEXT NOT NULL,
        author    TEXT NOT NULL,
        genre     TEXT,
        quantity  INTEGER DEFAULT 1,
        available INTEGER DEFAULT 1
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS members (
        member_id   INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT NOT NULL,
        email       TEXT UNIQUE NOT NULL,
        phone       TEXT,
        joined_date TEXT DEFAULT CURRENT_DATE
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS issued_books (
        issue_id    INTEGER PRIMARY KEY AUTOINCREMENT,
        book_id     INTEGER NOT NULL,
        member_id   INTEGER NOT NULL,
        issue_date  TEXT NOT NULL,
        due_date    TEXT NOT NULL,
        return_date TEXT,
        status      TEXT DEFAULT 'Issued',
        FOREIGN KEY (book_id)   REFERENCES books(book_id),
        FOREIGN KEY (member_id) REFERENCES members(member_id)
    )""")
    # Seed some sample data
    c.execute("SELECT COUNT(*) FROM books")
    if c.fetchone()[0] == 0:
        sample_books = [
            ("The Alchemist", "Paulo Coelho", "Fiction", 3, 3),
            ("Python Crash Course", "Eric Matthes", "Technology", 2, 2),
            ("Atomic Habits", "James Clear", "Self-Help", 4, 4),
            ("Clean Code", "Robert C. Martin", "Technology", 2, 2),
            ("Rich Dad Poor Dad", "Robert Kiyosaki", "Finance", 3, 3),
        ]
        c.executemany("INSERT INTO books (title,author,genre,quantity,available) VALUES (?,?,?,?,?)", sample_books)
    conn.commit()
    conn.close()

# ─────────────────────────────────────────────
#  ROUTES — DASHBOARD
# ─────────────────────────────────────────────

@app.route("/")
def index():
    conn = get_db()
    stats = {
        "total_books":    conn.execute("SELECT COUNT(*) FROM books").fetchone()[0],
        "total_members":  conn.execute("SELECT COUNT(*) FROM members").fetchone()[0],
        "issued_books":   conn.execute("SELECT COUNT(*) FROM issued_books WHERE status='Issued'").fetchone()[0],
        "returned_books": conn.execute("SELECT COUNT(*) FROM issued_books WHERE status='Returned'").fetchone()[0],
    }
    recent = conn.execute("""
        SELECT i.issue_id, b.title, m.name, i.issue_date, i.due_date, i.status
        FROM issued_books i
        JOIN books b ON i.book_id=b.book_id
        JOIN members m ON i.member_id=m.member_id
        ORDER BY i.issue_id DESC LIMIT 5
    """).fetchall()
    conn.close()
    return render_template("index.html", stats=stats, recent=recent)

# ─────────────────────────────────────────────
#  ROUTES — BOOKS
# ─────────────────────────────────────────────

@app.route("/books")
def books():
    q = request.args.get("q", "")
    conn = get_db()
    if q:
        rows = conn.execute(
            "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY title",
            (f"%{q}%", f"%{q}%")
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM books ORDER BY title").fetchall()
    conn.close()
    return render_template("books.html", books=rows, q=q)

@app.route("/books/add", methods=["GET","POST"])
def add_book():
    if request.method == "POST":
        title    = request.form["title"].strip()
        author   = request.form["author"].strip()
        genre    = request.form["genre"].strip()
        quantity = int(request.form["quantity"])
        conn = get_db()
        conn.execute("INSERT INTO books (title,author,genre,quantity,available) VALUES (?,?,?,?,?)",
                     (title, author, genre, quantity, quantity))
        conn.commit()
        conn.close()
        flash(f"✅ Book '{title}' added successfully!", "success")
        return redirect(url_for("books"))
    return render_template("add_book.html")

@app.route("/books/delete/<int:book_id>")
def delete_book(book_id):
    conn = get_db()
    book = conn.execute("SELECT title FROM books WHERE book_id=?", (book_id,)).fetchone()
    if book:
        conn.execute("DELETE FROM books WHERE book_id=?", (book_id,))
        conn.commit()
        flash(f"🗑️ Book '{book['title']}' deleted!", "info")
    conn.close()
    return redirect(url_for("books"))

# ─────────────────────────────────────────────
#  ROUTES — MEMBERS
# ─────────────────────────────────────────────

@app.route("/members")
def members():
    conn = get_db()
    rows = conn.execute("SELECT * FROM members ORDER BY name").fetchall()
    conn.close()
    return render_template("members.html", members=rows)

@app.route("/members/add", methods=["GET","POST"])
def add_member():
    if request.method == "POST":
        name  = request.form["name"].strip()
        email = request.form["email"].strip()
        phone = request.form["phone"].strip()
        conn  = get_db()
        try:
            conn.execute("INSERT INTO members (name,email,phone) VALUES (?,?,?)", (name,email,phone))
            conn.commit()
            flash(f"✅ Member '{name}' registered!", "success")
            return redirect(url_for("members"))
        except sqlite3.IntegrityError:
            flash("❌ Email already exists!", "error")
        finally:
            conn.close()
    return render_template("add_member.html")

# ─────────────────────────────────────────────
#  ROUTES — ISSUE / RETURN
# ─────────────────────────────────────────────

@app.route("/issue", methods=["GET","POST"])
def issue_book():
    conn    = get_db()
    books   = conn.execute("SELECT * FROM books WHERE available > 0 ORDER BY title").fetchall()
    members = conn.execute("SELECT * FROM members ORDER BY name").fetchall()
    if request.method == "POST":
        book_id   = int(request.form["book_id"])
        member_id = int(request.form["member_id"])
        issue_date = datetime.now().strftime("%Y-%m-%d")
        due_date   = (datetime.now() + timedelta(days=14)).strftime("%Y-%m-%d")
        conn.execute("INSERT INTO issued_books (book_id,member_id,issue_date,due_date) VALUES (?,?,?,?)",
                     (book_id, member_id, issue_date, due_date))
        conn.execute("UPDATE books SET available=available-1 WHERE book_id=?", (book_id,))
        conn.commit()
        flash(f"✅ Book issued successfully! Due date: {due_date}", "success")
        conn.close()
        return redirect(url_for("transactions"))
    conn.close()
    return render_template("issue.html", books=books, members=members)

@app.route("/return/<int:issue_id>")
def return_book(issue_id):
    conn        = get_db()
    record      = conn.execute("SELECT * FROM issued_books WHERE issue_id=? AND status='Issued'", (issue_id,)).fetchone()
    return_date = datetime.now().strftime("%Y-%m-%d")
    fine        = 0
    if record:
        due  = datetime.strptime(record["due_date"], "%Y-%m-%d")
        ret  = datetime.strptime(return_date, "%Y-%m-%d")
        if ret > due:
            fine = (ret - due).days * 2
        conn.execute("UPDATE issued_books SET return_date=?,status='Returned' WHERE issue_id=?",
                     (return_date, issue_id))
        conn.execute("UPDATE books SET available=available+1 WHERE book_id=?", (record["book_id"],))
        conn.commit()
        msg = f"✅ Book returned! " + (f"Fine: ₹{fine}" if fine else "No fine 🎉")
        flash(msg, "success" if not fine else "warning")
    conn.close()
    return redirect(url_for("transactions"))

@app.route("/transactions")
def transactions():
    conn = get_db()
    rows = conn.execute("""
        SELECT i.issue_id, b.title, m.name, i.issue_date, i.due_date, i.return_date, i.status
        FROM issued_books i
        JOIN books b ON i.book_id=b.book_id
        JOIN members m ON i.member_id=m.member_id
        ORDER BY i.issue_id DESC
    """).fetchall()
    conn.close()
    return render_template("transactions.html", transactions=rows)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
