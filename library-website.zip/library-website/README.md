# 📚 LibraBase — Library Management System
**Built by Amrutha Karamala | Python + Flask + SQLite | 2026**

## 🚀 Features
- Dashboard with stats
- Add / View / Search / Delete Books
- Register & View Members
- Issue & Return Books with due dates
- Auto fine calculation for overdue returns
- Full transaction history

## ▶️ Run Locally
```bash
pip install flask
python app.py
# Open http://localhost:5000
```

## 🌐 Deploy FREE on Render.com
1. Upload this folder to GitHub
2. Go to render.com → New Web Service
3. Connect your GitHub repo
4. Set: Build Command = `pip install -r requirements.txt`
5. Set: Start Command = `gunicorn app:app`
6. Click Deploy! ✅

## 🛠️ Tech Stack
- **Backend**: Python, Flask
- **Database**: SQLite (SQL)
- **Frontend**: HTML, CSS (Jinja2 templates)
- **Deployment**: Render.com (Free)
